<?php //$this->load->view('file/header'); ?>	
<?php //$this->load->view($view,$data); ?>
<?php //$this->load->view('file/footer'); ?>

<?php if ($header){ echo $header; } ?>

<?php if($footer){ echo $footer ; } ?>