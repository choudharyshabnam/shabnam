<?php
include('template/header.php');
?>
<!-- Team Section -->
<section id="team" class="bg-light-gray">
<div class="container">
<div class="row">
<div class="col-lg-12 text-center">
<h2 class="section-heading">Signup</h2>
<h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
<?php echo $this->session->flashdata('verify_msg'); ?>
</div>
</div>
<div class="row">
<div class="container">
<div class="row">
<div class="col-md-6 col-md-offset-3">
<div class="panel panel-login">
<div class="panel-heading">
<div class="row">
<div class="col-xs-6">


</div>

</div>
<hr>
</div>
<div class="panel-body">
<div class="row">
<div class="col-lg-12">

<h1>Register Here</h1>
            <?php $attributes = array("name" => "registrationform");
                echo form_open("template/register", $attributes);?>
                <div class="form-group">
                    <label for="name">First Name</label>
                    <input class="form-control" name="fname" placeholder="Your First Name" type="text" value="<?php echo set_value('fname'); ?>" required />
                    <span class="text-danger"><?php echo form_error('fname'); ?></span>
                </div>
				<br>

                <div class="form-group">
                    <label for="name">Last Name</label>
                    <input class="form-control" name="lname" placeholder="Last Name" type="text" value="<?php echo set_value('lname'); ?>" required/>
                    <span class="text-danger"><?php echo form_error('lname'); ?></span>
                </div>
				<br>
                
                <div class="form-group">
                    <label for="email">Email ID</label>
                    <input class="form-control" name="email" placeholder="Email-ID" type="email" value="<?php echo set_value('email'); ?>" required/>
                    <span class="text-danger"><?php echo form_error('email'); ?></span>
                </div>
				<br>

                <div class="form-group">
                    <label for="subject">Password</label>
                    <input class="form-control" name="password" placeholder="Password" type="password" required/>
                    <span class="text-danger"><?php echo form_error('password'); ?></span>
                </div>
				<br>

                <div class="form-group">
                    <label for="subject">Confirm Password</label>
                    <input class="form-control" name="cpassword" placeholder="Confirm Password" type="password" required/>
                    <span class="text-danger"><?php echo form_error('cpassword'); ?></span>
                </div>
				<br>

                <div class="form-group">
                    <button name="submit" type="submit" class="btn btn-default">Signup</button>
                    <button name="cancel" type="reset" class="btn btn-default">Cancel</button>
					<br>
					<br>
					
                </div>
                <?php echo form_close(); ?>
                <?php echo $this->session->flashdata('msg'); ?>
			</form>
			</div>
			</div>
			</div>
			</div>
			</div>
			</div>
			</div>

</div>
<!-- Clients Aside -->

<div class="row">
<div class="col-lg-8 col-lg-offset-2 text-center">
<p class="large text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut eaque, laboriosam veritatis, quos non quis ad perspiciatis, totam corporis ea, alias ut unde.</p>
</div>
</div>

</div>

</section>
<aside class="clients">
<div class="container">
<div class="row">
<div class="col-md-3 col-sm-6">
<a href="#">
<img src="<?php echo base_url(); ?>assets/img/logos/envato.jpg" class="img-responsive img-centered" alt="">
</a>
</div>
<div class="col-md-3 col-sm-6">
<a href="#">
<img src="<?php echo base_url(); ?>assets/img/logos/designmodo.jpg" class="img-responsive img-centered" alt="">
</a>
</div>
<div class="col-md-3 col-sm-6">
<a href="#">
<img src="<?php echo base_url(); ?>assets/img/logos/themeforest.jpg" class="img-responsive img-centered" alt="">
</a>
</div>
<div class="col-md-3 col-sm-6">
<a href="#">
<img src="<?php echo base_url(); ?>assets/img/logos/creative-market.jpg" class="img-responsive img-centered" alt="">
</a>
</div>
</div>
</div>
</aside>

<!-- Clients Aside -->

<?php
include('template/footer.php');
?>