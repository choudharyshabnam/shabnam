<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class User_ctrl extends MX_Controller {
	public function __construct()
    {
	        parent::__construct();
    }
	 
	public function index()
	{
		//echo "hello";die;
		$this->load->view('register');
		
	}
	 function register()
    {    
        $this->load->view('register');
    
        if(isset($_POST['submit']))
        {

			$this->load->helper(array('form','url'));
			//$this->load->library('form_validation');
        
                $data=array(
                    'fname'=> $this->input->post('fname'),
					'lname'=> $this->input->post('lname'),
                    'email'=> $this->input->post('email'),
                    'password'=> $this->input->post('password'));
                //print_r($data);
                $email=$this->input->post('email');
                $password=$this->input->post('password');
                $result=$this->user_model->get_data($email,$password);
               // print_r($result-> num_rows());die;
				 if($result -> num_rows() == 1) // if(@$data && !empty($data))
					{
					   //$this->session->set_flashdata('item','Email already Exist');
						echo 'email already exist';
						//redirect('template/register','refresh');
					   //echo "";
					}
			
            else{
				    $result=$this->user_model->insertUser($data);
					echo "sucessfully registered";
					$this->session->set_flashdata('user','sucessfully registered');
					//echo 'email already exist';
					//redirect('template/register','refresh');
                } 
				
				/* if($this->db->affected_rows()>0){
						//echo '<div class="alert alert-dismissable alert-success"><h4>Email already exist</h4></div>';
						//redirect('template/register','refresh');
						exit;
					}
					else{
						echo '<div class="alert alert-dismissable alert-danger"><h4>Successfully inserted</h4></div>';
						//redirect('template/register','refresh');
						exit;
					} */
        }
	}  
   
	
}
?>
