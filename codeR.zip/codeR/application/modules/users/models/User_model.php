<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User_model extends CI_Model{
	function __construct() {
		$this->load->database();
	}
		function insertUser($data)
		{
			return $this->db->insert('users',$data);

		}
		function get_data($email,$password){
				return $query=$this->db->
				get_where('users', array('email =' => $email,'password ='=>$password));
            }
			
}
