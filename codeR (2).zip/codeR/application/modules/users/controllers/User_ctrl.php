<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class User_ctrl extends MX_Controller {
	public function __construct()
    {
	        parent::__construct();
    }
	 
	public function index()
	{
		//echo "hello";die;
		$this->load->view('register');
		
	}
	 function register()
    {    
        $this->load->view('register');
    
        if(isset($_POST['submit']))
        {

			$this->load->helper(array('form','url'));
			//$this->load->library('form_validation');
        
                $data=array(
                    'fname'=> $this->input->post('fname'),
					'lname'=> $this->input->post('lname'),
                    'email'=> $this->input->post('email'),
                    'password'=> $this->input->post('password'));
                //print_r($data);
                $email=$this->input->post('email');
                $password=$this->input->post('password');
                $result=$this->user_model->get_data($email,$password);
               // print_r($result-> num_rows());die;
				 if($result -> num_rows() == 1) // if(@$data && !empty($data))
					{
					   //$this->session->set_flashdata('item','Email already Exist');
						echo 'email already exist';
						//redirect('template/register','refresh');
					   //echo "";
					}
			
            else{
				    $result=$this->user_model->insertUser($data);
					echo "sucessfully registered";
					$this->session->set_flashdata('user','sucessfully registered');
					//echo 'email already exist';
					//redirect('template/register','refresh');
                } 
				
				/* if($this->db->affected_rows()>0){
						//echo '<div class="alert alert-dismissable alert-success"><h4>Email already exist</h4></div>';
						//redirect('template/register','refresh');
						exit;
					}
					else{
						echo '<div class="alert alert-dismissable alert-danger"><h4>Successfully inserted</h4></div>';
						//redirect('template/register','refresh');
						exit;
					} */
        }
	}
function login_view()
    {
		$this->load->view('login_view');
		if(isset($_POST['submit']))
		{
			 $email = $this->input->post('email');
			 $password = $this->input->post('password');
			 //echo $email;
			  //echo $password; exit;
			 $result=$this->user_model->get_data($email,$password);
			  $results=$result->num_rows();
		    if($results >0)
			{
					$new=$result->row_array();
					//print_r($new);
					 $dpassword= $new['password'];
					//echo $dpassword;
				if($dpassword==$password)
				{
					$this->session->set_userdata('id',$new['id']);
					$this->session->set_userdata('fname',$new['fname']);
					$this->session->set_userdata('email',$new['email']);
					$this->session->set_userdata('password',$new['password']);
					$this->load->view('profile');
					echo "successfully login";
				    //redirect('template/login_view', 'refresh');
				}
				else
				{
					$this->session->set_flashdata('wrong','wrong password');
					redirect('user_ctrl/login_view', 'refresh');
				}

		
			}


		}
    }
	function gallery()
    {
			//$this->load->view('gallery');
			//echo "hello";exit;
			$data = array();
			//print_r($data);exit;
	    if($this->input->post('fileSubmit') && !empty($_FILES['userFiles']['name'])){
			$filesCount = count($_FILES['userFiles']['name']);
			//print_r($filesCount);exit;
			for($i = 0; $i < $filesCount; $i++){
				$_FILES['userFile']['name'] = $_FILES['userFiles']['name'][$i];
				$_FILES['userFile']['type'] = $_FILES['userFiles']['type'][$i];
				$_FILES['userFile']['tmp_name'] = $_FILES['userFiles']['tmp_name'][$i];
				$_FILES['userFile']['error'] = $_FILES['userFiles']['error'][$i];
				$_FILES['userFile']['size'] = $_FILES['userFiles']['size'][$i];

				$uploadPath = "./uploads/";
				$config['upload_path'] = $uploadPath;
				$config['allowed_types'] = 'gif|jpg|png';
				//print_r($config);die;
				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				if($this->upload->do_upload('userFile')){
					$fileData = $this->upload->data();
					$uploadData[$i]['file_name'] = $fileData['file_name'];
					$uploadData[$i]['created'] = date("Y-m-d H:i:s");
					$uploadData[$i]['modified'] = date("Y-m-d H:i:s");
					//print_r($uploadData);exit;
				}
			}

			if(!empty($uploadData)){
				//Insert file information into the database
				$insert = $this->user_model->insert($uploadData);
				$statusMsg = $insert?'Files uploaded successfully.':'Some problem occurred, please try again.';
				$this->session->set_flashdata('statusMsg',$statusMsg);
			}
		}
		//Get files data from database
		$data['files'] = $this->user_model->getRows();
		//print_r($data['files']);die;
		//Pass the files data to view
		$this->load->view('gallery', $data);
    }
	
	
}
?>
