<?php
include('page/header.php');
?>
<section id="about">
<div class="container">
<div class="row">
<div class="col-lg-12 text-center">
<h2 class="section-heading">Gallery</h2>
<h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
</div>
</div>
<div class="container">
<div class="row">
<p><?php echo $this->session->flashdata('statusMsg'); ?></p>
<form enctype="multipart/form-data" action="" method="post">
<div class="form-group">
<label>Choose Files</label>
<input type="file" class="" name="userFiles[]" multiple/>
</div>
<div class="form-group">
<input class="" type="submit" name="fileSubmit" value="UPLOAD"/>
</div>
</form>
</div>
<div class="row">
<div class="col-lg-12">
<div class="gallery">
<?php //print_r($files); ?>
<?php if(!empty($files)): foreach($files as $file): ?>
<div class="col-lg-4">
<div class="item">
<img src="<?php echo base_url('uploads/'.$file['file_name']); ?>" alt="" style="height: 300px; width: 300px;" >
<p>Uploaded On <?php echo date("j M Y",strtotime($file['created'])); ?></p>
</div>
</div>
<?php endforeach; else: ?>
<p>Image(s) not found.....</p>
<?php endif; ?>
</div>
</div>
</div>
<script>
        $(document).ready(function (){
            loadgallery();
             
             
            function readURL(input) {
                $("#preview").show();
            if (input.files && input.files[0]) {
                var reader = new FileReader();
 
                reader.onload = function (e) {
                    $('#preview').attr('src', e.target.result);
                };
 
                reader.readAsDataURL(input.files[0]);
            }
        }
        $("#userfile").change(function(){
            readURL(this);
        });
                $('form').ajaxForm({
                beforeSend: function() {
                    $("#loader").show();
                },
                complete: function(xhr) {
                $("#response").html(xhr.responseText);
                $("#loader").hide();
                $('form').resetForm();
                loadgallery();
                }
            }); 
            
           function  loadgallery(){
           $.ajax({
              //url:'http://localhost/tuts/CI_upload/index.php/welcome/fillGallery',
			  url:'<?php echo base_url(); ?>gallery/fillGallery',
              type:'GET'
            }).done(function (data){
                $("#gallery").html(data);
                var btnDelete  = $("#gallery").find($(".btn-delete"));
                (btnDelete).on('click', function (e){
                    e.preventDefault();
                    var id = $(this).attr('id');
                    $("#"+id+"g").hide();
                    $.ajax({
						url:'<?php echo base_url(); ?>gallery/deleteimg',
                        //url:'http://localhost/tuts/CI_upload/index.php/welcome/deleteimg',
                        data:'id='+id,
                        type:'POST'
                    }).done(function (data){
                         
                    });
                });
                 
            });
           }
            
        });
</script>
</section>

<?php
include('page/footer.php');
?>