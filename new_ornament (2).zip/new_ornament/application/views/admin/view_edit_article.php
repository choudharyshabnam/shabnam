
       <?php include('page/header.php'); ?>
        
        <div class="container well" style="margin-top: -15px; width: 83.5%">
	<div class="row clearfix">
		<div class="col-md-12 column">
                    <form class="form-horizontal cus-form" id="Edit_transaction" method="POST" action="<?php echo base_url().'blogs/view_edit' ?>">
                        <?php foreach($query->result() as $row): ?>
                    <table class="table table-bordered">
                     <!--   <tr>
                            <td colspan="2">
                                <label>Select Category:<small>(<?php //echo $item_val ?>)</small></label>
                                <select id="name" name="category" class="form-control input-sm">
                                    <option selected="selected" value="<?php //echo $row->Category_id ?>"><?php //echo $item_val ?></option>
                                <?php //foreach($listquery->result() as $row1): ?>
                                    <option value="<?php //echo $row1->id ?>"><?php //echo $row1->Type ?></option>
                                <?php //endforeach; ?>
                                </select>
                            </td>
                        </tr>-->
						   <tr>
                            <td colspan="2">
                                <label>Select Category:<small>(<?php echo $item_val ?>)</small></label>
                                <select id="name" name="category" class="form-control input-sm">
                                    <option selected="selected" value="<?php echo $row->Category_id ?>"><?php echo $item_val ?></option>
                                <?php $sel1 = mysql_query("select * from category");
									while($row1=mysql_fetch_array($sel1))
									{
								?>
                                    <option value="<?php echo $row1['id']; ?>"><?php echo $row1['Type']; ?></option>
									<?php } ?>
                                </select>
                            </td>
                        </tr>
						
						
                        <tr>
                            <td>
                                <label>Title</label>  
                                <input id="weight" name="title" placeholder="placeholder" class="form-control input-sm" type="text" value="<?php echo $row->Title ?>">
                                <span class="help-block">Title.</span>  
                
                            </td>
                           
                  
                        <tr>
                            <td colspan="2">
                                <label>Date:<small>(<?php echo date('F jS Y', strtotime($row->created)); ?>)</small></label>
                                <input type="text" id="datepicker" name="date" class="form-control input-sm" value="<?php echo $row->created ?>"/>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <label>Comment</label>
                                <textarea class="form-control" id="comment" name="comment"><?php echo $row->Description ?></textarea>
                            </td>
                        </tr>
                        <input type="hidden" name="id" value="<?php echo $row->id ?>"/>
                        
                    </table>
                    <div style="padding-left: 10px; padding-bottom: 10px; margin-top: -8px;">
                        <button type="submit" name="submit" class="btn btn-success">Submit</button>
                        <a href="<?php echo base_url()?>dashbord" id="cancle" name="cancle" class="btn btn-warning">Cancel</a>                
                    </div>
                       <?php endforeach; ?>
                </form>
			
		</div>
             
	</div>
</div>
        
        
       
 <script src="<?php echo base_url() ?>bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
 
 
 <script>
    $(function(){
        
        $("#Edit_transaction").submit(function( event ) {
           event.preventDefault();
            var url = $(this).attr('action');
            console.log(url);
            
            $.ajax({
                url: url,
                data: $("#Edit_transaction").serialize(),
                type: $(this).attr('method')
              }).done(function(data) {
                  $('#ret').html(data);
//                  window.location.reload();
//                $('#do_edit_post')[0].reset();
              });
            
        });
        
$( "#datepicker" ).datepicker({
defaultDate: "+1w",
changeMonth: true,
numberOfMonths: 1,
dateFormat: "yy-mm-dd",
onClose: function( selectedDate ) {
$( "#to" ).datepicker( "option", "minDate", selectedDate );
}
});
    });

</script>
<?php include('page/footer.php'); ?>
 
    </body>
</html>