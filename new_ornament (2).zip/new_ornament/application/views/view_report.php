<style>
    	.row{
		    margin-top:40px;
		    padding: 0 10px;
		}
		.clickable{
		    cursor: pointer;   
		}

		.panel-heading div {
			margin-top: -18px;
			font-size: 15px;
		}
		.panel-heading div span{
			margin-left:5px;
		}
		.panel-body{
			display: none;
		}
</style>
<script>
/**
*   I don't recommend using this plugin on large tables, I just wrote it to make the demo useable. It will work fine for smaller tables 
*   but will likely encounter performance issues on larger tables.
*
*		<input type="text" class="form-control" id="dev-table-filter" data-action="filter" data-filters="#dev-table" placeholder="Filter Developers" />
*		$(input-element).filterTable()
*		
*	The important attributes are 'data-action="filter"' and 'data-filters="#table-selector"'
*/
(function(){
    'use strict';
	var $ = jQuery;
	$.fn.extend({
		filterTable: function(){
			return this.each(function(){
				$(this).on('keyup', function(e){
					$('.filterTable_no_results').remove();
					var $this = $(this), 
                        search = $this.val().toLowerCase(), 
                        target = $this.attr('data-filters'), 
                        $target = $(target), 
                        $rows = $target.find('tbody tr');
                        
					if(search == '') {
						$rows.show(); 
					} else {
						$rows.each(function(){
							var $this = $(this);
							$this.text().toLowerCase().indexOf(search) === -1 ? $this.hide() : $this.show();
						})
						if($target.find('tbody tr:visible').size() === 0) {
							var col_count = $target.find('tr').first().find('td').size();
							var no_results = $('<tr class="filterTable_no_results"><td colspan="'+col_count+'">No results found</td></tr>')
							$target.find('tbody').append(no_results);
						}
					}
				});
			});
		}
	});
	$('[data-action="filter"]').filterTable();
})(jQuery);

$(function(){
    // attach table filter plugin to inputs
	$('[data-action="filter"]').filterTable();
	
	$('.container').on('click', '.panel-heading span.filter', function(e){
		var $this = $(this), 
			$panel = $this.parents('.panel');
		
		$panel.find('.panel-body').slideToggle();
		if($this.css('display') != 'none') {
			$panel.find('.panel-body input').focus();
		}
	});
	$('[data-toggle="tooltip"]').tooltip();
})
</script>
<div class="container">
<a href="#" class="cus-icon pull-left"><img id='back' src='<?php echo base_url() ?>bootstrap/images/icon/back.png'/></a>
    <h1>Click the filter icon <small>(<i class="glyphicon glyphicon-filter"></i>)</small></h1>
    	<div class="row">
			<div class="col-md-12">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title"><?php echo $item ?></h3>
						<div class="pull-right">
							<span class="clickable filter" data-toggle="tooltip" title="Toggle table filter" data-container="body">
								<i class="glyphicon glyphicon-filter"></i>
							</span>
						</div>
					</div>
					<div class="panel-body">
						<input type="text" class="form-control" id="dev-table-filter" data-action="filter" data-filters="#dev-table" placeholder="Filter Developers" />
					</div>
					<table class="table table-hover" id="dev-table">
						<thead>
							<tr>
								<th>ID</th>
								<th>Weight</th>
								<th>Nug</th>
								<th>Total Weight</th>
								<th>Transaction Type</th>
								<th>Created</th>
                                
							</tr>
						</thead>
					    <tbody>


<?php foreach($query->result() as $row): ?>
<tr>
<td data-title="Country"><?php echo $row->id ?></td>
<td data-title="Prefix"><?php echo $row->weight ?></td>
<td class="numeric" data-title="Fixed (RM/30sec)"><?php echo $row->nug ?></td>
<td class="numeric" data-title="Mobile (RM/30sec)"><?php echo $row->total_weight ?></td>
<td data-title="Country"><?php echo $row->transaction_type ?></td>
<td data-title="Country"><?php echo $row->created ?></td>
</tr>
<?php endforeach; ?>
</tbody>

					</table>
					<div id="result" style="width: 100%; background: #F8F8F8; padding:12px;">
                        <i class="glyphicon glyphicon-print print" title="print" style="cursor: pointer"></i>&nbsp;&nbsp;<strong>Remaining stock</strong>&nbsp;&nbsp;&nbsp;
                        <span class="spntext">Total Quantity:<?php echo $quantity ?> <small><sub>(piece)</sub></small></span>&nbsp;&nbsp;&nbsp;&nbsp;
                        <span class="spntext">Total Weight:<?php echo $weight ?> <small><sub>(grms)</sub></small></span>&nbsp;&nbsp;&nbsp;&nbsp;
                    </div>
				</div>
			</div>
		</div>
	</div>
	
	<script>
$(document).ready(function (){
    $("#back").on('click', function (e){
    e.preventDefault();
    window.history.back();
    });
    
    $(".print").click(function (){
        window.print();
    });
});

	</script>