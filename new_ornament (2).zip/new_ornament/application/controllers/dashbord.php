<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashbord extends CI_Controller {
    
  public function __construct() {
        parent::__construct();
        $this->load->model('Dashbord_model');
        $this->load->model('Init_model');
        $this->load->library('excel');
    }
    
	
	public function index()
	{
		$this->is_logged_in();
		$data['query'] = $this->Init_model->init();
		$data['listquery'] = $this->Init_model->listItem();
		$this->load->view('admin/view_header');
		$this->load->view('admin/view_dashbord', $data);
	}
	
	
	public function is_logged_in(){
        
        header("cache-Control: no-store, no-cache, must-revalidate");
        header("cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
        $is_logged_in = $this->session->userdata('logged_in');
        
        if(!isset($is_logged_in) || $is_logged_in!==TRUE)
        {
            redirect('admin/');
        }
    }
	
	public function add_transaction()
	{
		$this->form_validation->set_rules('item','Item','required');
		$this->form_validation->set_rules('weight','Weight','required|min_length[1]|max_length[7]|numeric');
		$this->form_validation->set_rules('nug','Nug','required|min_length[1]|max_length[3]|numeric');
		$this->form_validation->set_rules('transaction_type','Transaction Type','required');
		$this->form_validation->set_rules('date', 'Date', 'required');
		if($this->form_validation->run()==FALSE){
			echo '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">*</button><small>'.validation_errors().'</small></div>';
		}
		else{
			$item = $this->input->post('item');
			$weight = $this->input->post('weight');
			$nug = $this->input->post('nug');
			$transaction_type = $this->input->post('transaction_type');
			$date = $this->input->post('date');
			$comment = $this->input->post('comment');
			$this->Dashbord_model->add_transaction($item,$weight,$nug,$transaction_type,$date,$comment);
		}
		
	}
	
	public function delete_entry()
	{
		$this->Dashbord_model->delete_post($this->input->post('id'));
	}
	
	public function edit_entry(){
		$id = $this->uri->segment(3);
		$data['item_val']=str_replace("%20","",$this->uri->segment(4));
		$data['query'] = $this->db->get_where('transaction',array('id'=>$id));
		$data['listquery'] = $this->Init_model->listItem();
		$this->load->view('admin/view_header');
		$this->load->view('admin/view_edit_entry',$data);
	}
	
	public function view_edit()
	{
		$item = $this->input->post('item');
		$weight = $this->input->post('weight');
		$nug = $this->input->post('nug');
		$transaction_type = $this->input->post('transaction_type');
		$date = $this->input->post('date');
		$comment = $this->input->post('comment');
		$id = $this->input->post('id');
		$this->Dashbord_model->view_edit($item,$weight,$nug,$transaction_type,$date,$comment,$id);	
	}

	public function list_edit()
			{
				$item = $this->input->post('item');
				$comment = $this->input->post('comment');
				$id = $this->input->post('id');
				$this->Itemlist_model->list_edit($item, $comment, $id);
			}
	
	/* function do_edit(){
        
                $item = $this->input->post('item');
                $weight = $this->input->post('weight');
                $nug = $this->input->post('nug');
                $transaction_type = $this->input->post('transaction_type');
                $date = $this->input->post('date');
                $comment = $this->input->post('comment');
                $id = $this->input->post('id');
                $this->Dashbord_model->do_edit($item, $weight, $nug, $transaction_type, $date, $comment, $id);

            } */

    /* function edit_entry(){
               $id = $this->uri->segment(3);
               $data['item_val'] = str_replace("%20"," ",$this->uri->segment(4));
               $data['query'] =   $this->db->get_where('transaction', array('id'=>$id));
               $data['listquery'] = $this->Init_model->listItem();
               $this->load->view('admin/view_header');
               $this->load->view('admin/view_edit_entry',$data);

            } */
	
	public function manageUser()
	{
		if($this->session->userdata('role') == 'admin'){
			$data['query'] = $this->db->get('auth');
			$this->load->view('admin/view_header');
			$this->load->view('admin/viewuser',$data);			
		}
		else{
         $this->load->view('head_section');
         $this->load->view('invaliduser');
       }
	}
	
	public function createUser()
	{
		if($this->session->userdata('role') == 'admin')
		{
			$this->form_validation->set_rules('name','User name','callback_username_check');
			//$this->form_validation->set_rules('email','Email Address','callback_email_check');
			$this->form_validation->set_rules('email','Email Address','callback_isEmailExist');
			if($this->form_validation->run()== FALSE)
			{
				echo '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">*</button><small>'.validation_errors().'</small></div>';
				exit;
			}
			else{
				if($this->Dashbord_model->createUser())
				{
					echo '<div class="alert alert-dismissable alert-success">User Added Successfully</div>';
					exit;
				}
				else{
					echo '<div class="alert alert-dismissable alert-danger">Something Went Wrong</div>';
					exit;
				}
			}
		}
		else{
			echo '<div class="alert alert-dismissable alert-danger">Invalid User</div>';
			exit;
		}
	}
	
	
		function delUser()
	{
		if($this->session->userdata('role')== 'admin')
		{
			$id = $this->input->get_post('id');
			$this->db->where('id', $id);
			$this->db->delete('auth');
			if($this->db->affected_rows() > 0)
			{
				$this->session->set_flashdata('falsh','<p class="alert alert-success"> One Item Deleted Seccessfully</p>');
			}
			else{
				$this->session->set_flashdata('falsh','<p class="alert alert-danger">Sorry! Deleted UnSuccessfully</p>');
			}
			
		}else{
			
			 $this->session->set_flashdata('falsh', '<p class="alert alert-danger">Sorry! You have no rights to delete</p>'); 
		}
		redirect('dashbord/manageUser');
		exit;
	}
	

	/* public function delUser()
	{
		$this->Dashbord_model->delete_user($this->input->post('id'));
	} */
	
/* 				public function transactionExcel()
    {
                $this->excel->setActiveSheetIndex(0);
                //name the worksheet
                $this->excel->getActiveSheet()->setTitle('Users');
                //set cell A1 content with some text
                $this->excel->getActiveSheet()->setCellValue('A1', 'Users Excel Sheet');
                $this->excel->getActiveSheet()->setCellValue('A4', 'S.No.');
                $this->excel->getActiveSheet()->setCellValue('B4', 'User Name');
                $this->excel->getActiveSheet()->setCellValue('C4', 'User Email');
				$this->excel->getActiveSheet()->setCellValue('D4', 'Password');
				$this->excel->getActiveSheet()->setCellValue('E4', 'Role');
				$this->excel->getActiveSheet()->setCellValue('F4', 'Is Active');
				$this->excel->getActiveSheet()->setCellValue('G4', 'Created');
                //merge cell A1 until C1
                $this->excel->getActiveSheet()->mergeCells('A1:C1');
                //set aligment to center for that merged cell (A1 to C1)
                $this->excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                //make the font become bold
                $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
                $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(16);
                $this->excel->getActiveSheet()->getStyle('A1')->getFill()->getStartColor()->setARGB('#333');
       for($col = ord('A'); $col <= ord('C'); $col++){
                //set column dimension
                $this->excel->getActiveSheet()->getColumnDimension(chr($col))->setAutoSize(true);
                 //change the font size
                $this->excel->getActiveSheet()->getStyle(chr($col))->getFont()->setSize(12);
                 
                $this->excel->getActiveSheet()->getStyle(chr($col))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
                //retrive contries table data
                $sql = "select * from auth";
				$rs = $this->db->query($sql);
				//$rs = $this->db->get('countries');
                $exceldata="";
        foreach ($rs->result_array() as $row){
                $exceldata[] = $row;
        }
                //Fill data 
                $this->excel->getActiveSheet()->fromArray($exceldata, null, 'A4');
                 
                $this->excel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $this->excel->getActiveSheet()->getStyle('B4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $this->excel->getActiveSheet()->getStyle('C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$this->excel->getActiveSheet()->getStyle('D4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$this->excel->getActiveSheet()->getStyle('E4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$this->excel->getActiveSheet()->getStyle('F4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$this->excel->getActiveSheet()->getStyle('G4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                 
                $filename='Users.xls'; //save our workbook as this file name
                header('Content-Type: application/vnd.ms-excel'); //mime type
                header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
                header('Cache-Control: max-age=0'); //no cache
 
                //save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
                //if you want to save it as .XLSX Excel 2007 format
                $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
                //force user to download the Excel file without writing it to server's HD
                $objWriter->save('php://output');
                 
		} */
		
		public function searchTransaction()
		{
			$data['query']= $this->db->get('item');
			//$data['items'] = $this->db->get('transaction');
			$this->load->view('admin/view_header');
			$this->load->view('admin/view_searchEntry',$data);
		}
		
		public function searchItem()
		{
			$item = $this->input->post('item');
			if(!empty($item)){
				$this->Dashbord_model->searchItem($item);
			}
			else{
				 echo'<tr><td colspan="9"><h2 style="color: #9F6000;">Sorry ! no search result found</h2></td></tr>';
			}
		}
		
/* 		function delUser()
	{
		if($this->session->userdata('role')== 'admin')
		{
			$id = $this->input->get_post('id');
			$this->db->where('id', $id);
			$this->db->delete('auth');
			if($this->db->affected_rows() > 0)
			{
				$this->session->set_flashdata('falsh','<p class="alert alert-success"> One Item Deleted Seccessfully</p>');
			}
			else{
				$this->session->set_flashdata('falsh','<p class="alert alert-danger">Sorry! Deleted UnSuccessfully</p>');
			}
			
		}else{
			
			 $this->session->set_flashdata('falsh', '<p class="alert alert-danger">Sorry! You have no rights to deltete</p>'); 
		}
		redirect('dashbord/manageUser');
		exit;
	} */
		
		
		
		public function searchAdvance()
		{
			$from = $this->input->post('from');
			$to = $this->input->post('to');
			if(empty($from) && empty($to))
			{
				echo '<tr><td colspan="9"><h2 style="color: #9F6000;">Sorry ! no Search Result found</h2></td></tr>';
				exit;
			}
			else{
				$this->Dashbord_model->searchAdvance($from, $to);
			}
		}
		
		
		public function batchDelete()
		{
			if($this->session->userdata('role')=='admin')
			{
				
				$ids = explode(',',$this->input->get_post('ids'));
				//echo "<pre>";
				//print_r($id);
				//echo gettype($id);
				//die();
				foreach($ids as $id){
				$this->db->where('id', $id);
				$this->db->delete('transaction');
				}
				if($this->db->affected_rows() > 0)
				{
					echo '<div class="alert alert-dismissable alert-success"><h4>Deleted Successfully</h4></div>';
					exit;
				}
				else{
					echo '<div class="alert alert-dismissable alert-danger"><h4>Something Wrong</h4></div>';
					exit;
				}
			}
			else{
				echo '<div class="alert alert-dismissable alert-danger"><h4>Invalid User</h4></div>';
				exit;
			}
		}
	
}
   
 