<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Itemlist extends CI_Controller {
    
  public function __construct() {
        parent::__construct();
        $this->load->model('Itemlist_model');
		$this->load->library('excel');
        //$this->load->model('Init_model');
        
    }
    	
	public function index()
	{
		$this->get_pagination();
		$this->is_logged_in();
		//$data['rs'] = $this->db->('item');
		//$this->load->view('admin/view_itemlist', $data);
		$this->db->order_by('item');
		$data['query'] = $this->db->get('item', 4, $this->uri->segment(3));
		//$data['query'] = $this->Init_model->init();
		//$data['listquery'] = $this->Init_model->listItem();
		$this->load->view('admin/view_header');
		$this->load->view('admin/view_itemlist', $data);
	}
	
	
	public function is_logged_in(){
        
        header("cache-Control: no-store, no-cache, must-revalidate");
        header("cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
        $is_logged_in = $this->session->userdata('logged_in');
        
        if(!isset($is_logged_in) || $is_logged_in!==TRUE)
        {
            redirect('admin/');
        }
    }
	
	
	public function add_item()
	{
		$this->form_validation->set_rules('item','Item Value','required|min_length[5]|max_length[50]');
		$this->form_validation->set_rules('comment','Comment data','required|max_length[500]');
		if($this->form_validation->run()== FALSE)
		{
			echo '<div class="alert alert-dismissable alert-danger"><button class="close" type="button" data-dismiss="alert" aria-hidden="true">*</button><small>'.validation_errors().'</small></div>';
		}
		else
		{
			$item = $this->input->post('item');
			$comment = $this->input->post('comment');
			
			$this->Itemlist_model->add_item($item,$comment);
		}
		
	}
	public function delete_item()
	{
		$this->Itemlist_model->delete_item($this->input->post('id'));
	}
	
	
	    public function get_pagination(){
            $config['base_url'] = base_url().'itemlist/index/';
            $config['total_rows'] = $this->db->get('item')->num_rows();
            $config['per_page'] = 4;
            $config['num_links'] = 5;
            
            //appy css on pagination
            
//            $config['page_query_string'] = TRUE;
//            // $config['use_page_numbers'] = TRUE;
//            $config['query_string_segment'] = 'page';

            $config['full_tag_open'] = '<ul class="pagination pagination-sm">';
            $config['full_tag_close'] = '</ul><!--pagination-->';

            $config['first_link'] = '&laquo;';
            $config['first_tag_open'] = '<li class="prev page">';
            $config['first_tag_close'] = '</li>';
//
            $config['last_link'] = '&raquo;';
            $config['last_tag_open'] = '<li class="next page">';
            $config['last_tag_close'] = '</li>';
//
            $config['next_link'] = '&rarr;';
            $config['next_tag_open'] = '<li class="next page">';
            $config['next_tag_close'] = '</li>';
//
            $config['prev_link'] = '&larr;';
            $config['prev_tag_open'] = '<li class="prev page">';
            $config['prev_tag_close'] = '</li>';

            $config['cur_tag_open'] = '<li class="active"><a href="">';
            $config['cur_tag_close'] = '</a></li>';

            $config['num_tag_open'] = '<li class="page">';
            $config['num_tag_close'] = '</li>';

            //   $config['display_pages'] = FALSE;
            // 
//          $config['anchor_class'] = 'follow_link';
            
            $this->pagination->initialize($config);
    }
	
			public function exportItemExcel()
    {
                $this->excel->setActiveSheetIndex(0);
                //name the worksheet
                $this->excel->getActiveSheet()->setTitle('Items');
                //set cell A1 content with some text
                $this->excel->getActiveSheet()->setCellValue('A1', 'Items Excel Sheet');
                $this->excel->getActiveSheet()->setCellValue('A4', 'S.No.');
                $this->excel->getActiveSheet()->setCellValue('B4', 'Item Name');
                $this->excel->getActiveSheet()->setCellValue('C4', 'Comments');
				$this->excel->getActiveSheet()->setCellValue('D4', 'Created');
                //merge cell A1 until C1
                $this->excel->getActiveSheet()->mergeCells('A1:C1');
                //set aligment to center for that merged cell (A1 to C1)
                $this->excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                //make the font become bold
                $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
                $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(16);
                $this->excel->getActiveSheet()->getStyle('A1')->getFill()->getStartColor()->setARGB('#333');
       for($col = ord('A'); $col <= ord('C'); $col++){
                //set column dimension
                $this->excel->getActiveSheet()->getColumnDimension(chr($col))->setAutoSize(true);
                 //change the font size
                $this->excel->getActiveSheet()->getStyle(chr($col))->getFont()->setSize(12);
                 
                $this->excel->getActiveSheet()->getStyle(chr($col))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
                //retrive contries table data
                $sql = "select * from item";
				$rs = $this->db->query($sql);
				//$rs = $this->db->get('countries');
                $exceldata="";
        foreach ($rs->result_array() as $row){
                $exceldata[] = $row;
        }
                //Fill data 
                $this->excel->getActiveSheet()->fromArray($exceldata, null, 'A4');
                 
                $this->excel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $this->excel->getActiveSheet()->getStyle('B4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $this->excel->getActiveSheet()->getStyle('C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                 
                $filename='Items.xls'; //save our workbook as this file name
                header('Content-Type: application/vnd.ms-excel'); //mime type
                header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
                header('Cache-Control: max-age=0'); //no cache
 
                //save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
                //if you want to save it as .XLSX Excel 2007 format
                $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
                //force user to download the Excel file without writing it to server's HD
                $objWriter->save('php://output');
                 
		}	

			public function edit_list()
			{
				//$this->Itemlist_model->edit_list($this->input->post('id'));
				$id = $this->uri->segment(3);
				$data['query'] = $this->db->get_where('item',array('id'=>$id));
				$this->load->view('admin/view_header');
				$this->load->view('admin/view_editItemlist',$data);
				
			} 
			
			public function list_edit()
			{
				$item = $this->input->post('item');
				$comment = $this->input->post('comment');
				$id = $this->input->post('id');
				$this->Itemlist_model->list_edit($item, $comment, $id);
			}
			
	
}




	    
   
 