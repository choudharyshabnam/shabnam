<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Blogs extends CI_Controller {
    
  public function __construct() {
        parent::__construct();
        $this->load->model('Blogs_model');
        $this->load->model('Init_model');
        //$this->load->library('excel');
    }
    
	
	public function index()
	{
		$this->is_logged_in();
		$data['query'] = $this->Init_model->inits();
		//$data['listquery'] = $this->Init_model->listcategory();
		$this->load->view('admin/view_header');
		$this->load->view('admin/view_blogs', $data);
	}
	
	
	public function is_logged_in(){
        
        header("cache-Control: no-store, no-cache, must-revalidate");
        header("cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
        $is_logged_in = $this->session->userdata('logged_in');
        
        if(!isset($is_logged_in) || $is_logged_in!==TRUE)
        {
            redirect('admin/');
        }
    }
	
	public function add_article()
	{
		$this->form_validation->set_rules('category', 'Category Name','required');
		$this->form_validation->set_rules('title','Tile','required');
		$this->form_validation->set_rules('comment','Description','required');
		//$this->form_validation->set_rules('date','Date');
		if($this->form_validation->run()==FALSE){
			echo '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">*</button><small>'.validation_errors().'</small></div>';
		}
		else{
			$category = $this->input->post('category');
			$title = $this->input->post('title');
			$comment = $this->input->post('comment');
			//$date = $this->input->post('date');
			$this->Blogs_model->add_article($category,$title,$comment);
		}
	}
	
	
	public function delete_article()
	{
		$this->Blogs_model->delete_article($this->input->post('id'));
	}
		
	public function edit_article(){
		$id = $this->uri->segment(3);
		$data['item_val']=str_replace("%20","",$this->uri->segment(4));
		$data['query'] = $this->db->get_where('article',array('id'=>$id));
		//$data['listquery'] = $this->Init_model->listcategory();
		$this->load->view('admin/view_header');
		$this->load->view('admin/view_edit_article',$data);
	}	
	
	
}
   
 