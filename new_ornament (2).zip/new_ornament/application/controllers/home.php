<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Home extends CI_Controller{
	function __construct(){
	parent::__construct();
	$this->load->model('Contact_model');
	$this->load->helper('url');
	}
	
	
	public function index(){
		$data['query'] = $this->db->get('item');
		$this->load->view('head_section',$data);
		$this->load->view('view_homes',$data);
		$this->load->view('footer');
	}
	
	public function view_report()
	{
		
		$id = $this->uri->segment(3);		
		$data['item'] = str_replace('%20',' ',$this->uri->segment(2));
		
		$data['query'] = $this->db->get_where('transaction', array('item_id' => $id));		
		$quantity = 0;
		$weight = 0.0000;
		foreach($data['query']->result() as $row)
		{
			/* echo "<pre>";
			print_r($row->transaction_type);
			die(); */
			$type = ($row->transaction_type=='buy')?'+':'-';
			$quantity = $quantity .$type.$row->nug;
			$weight = $weight .$type.$row->total_weight;							
		}
		$data['weight'] = eval("return($weight);");
		/*  echo "<pre>";
			print_r($data);
			die(); */ 
		$data['quantity'] = eval("return($quantity);");
		
		$this->load->view('head_section');
		$this->load->view('view_report',$data);
		$this->load->view('footer');
	}
	
	public function gallery()
	{
		$data['query'] = $this->db->get('gallery');
		$this->load->view('head_section',$data);
		$this->load->view('view_gallery1',$data);
		$this->load->view('footer');
	}
	
	public function blogs()
	{
		$data['query'] = $this->db->get('article');
		$this->load->view('head_section', $data);
		$this->load->view('view_blogs',$data);
		$this->load->view('footer');
	}
	public function contact()
	{
		$this->load->view('head_section');
		$this->load->view('contactus');
		$this->load->view('footer');
	}
	
	public function contacts()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('name', 'Name','required|min_length[5]');
		$this->form_validation->set_rules('email','Name','required');
		$this->form_validation->set_rules('subject','Subject','required');
		$this->form_validation->set_rules('message','Message','required|min_length[5]|max_length[500]');
		if($this->form_validation->run()==FALSE){
			echo '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">*</button><small>'.validation_errors().'</small></div>';
		}
		else{
			/* $config = Array( 
			  'protocol' => 'smtp', 
			  'smtp_host' => 'ssl://smtp.googlemail.com', 
			  'smtp_port' => 465, 
			  'smtp_user' => 'sunpreetckd@gmail.com', 
			  'smtp_pass' => 'shaanshergill90', );
			 $this->load->library('email', $config); */ 
			 $name = $this->input->post('name');
			$email = $this->input->post('email');
			$subject = $this->input->post('subject');
			$message = $this->input->post('message');
			 
			  /* $this->email->set_newline("\r\n");
			  $this->email->from('email@gmail.com', 'Name');
			  $this->email->to('sunp@yahoo.com');
			  $this->email->subject(' My mail through codeigniter from localhost '); 
			  $this->email->message('Hello World…');
			  if (!$this->email->send()) {
				show_error($this->email->print_debugger()); }
			  else {
				echo 'Your e-mail has been sent!';
			  }
				 */
			
			
			$this->Contact_model->contacts($name,$email,$subject,$message);
			
		}
	}
	
}







	
