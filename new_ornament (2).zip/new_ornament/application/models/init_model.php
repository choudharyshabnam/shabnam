<?php



class Init_model extends CI_Model
{
		function __construct(){
			parent::__construct();
			$this->index();
		}
		
		function index()
		{
			
		}
    
		function listItem()
		{
			$this->db->order_by('item');
		$query = $this->db->get('item');
		 return $query;
		}
		
		function init()
		{
			$segment = intval($this->uri->segment(3));
			$sql = "SELECT item.item, item.id as itemID, transaction.id,transaction.weight, transaction.nug,transaction.total_weight,transaction.transaction_type,transaction.comment, transaction.created from transaction LEFT JOIN item ON transaction.item_id = item.id ORDER BY transaction.id DESC";
			$query = $this->db->query($sql);
			return $query;
		
		}
		
		/* function listcategory()
		{
			$this->db->order_by('category');
			$query = $this->db->get('category');
			return $query;
			} */
			
 	function inits()
		{
		$segment = intval($this->uri->segment(3));
		$sql = "SELECT category.Type, category.id  as categoryID, article.id, article.Title, article.Description, article.created from article LEFT JOIN category ON article.Category_id = category.id ORDER BY article.id DESC";
		$query = $this->db->query($sql);
		return $query;
		}
    
}






    



