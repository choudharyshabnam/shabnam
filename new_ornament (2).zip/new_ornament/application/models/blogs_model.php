<?php

class Blogs_model extends CI_Model
{
    
   function __construct() {
        parent::__construct();
    }
    
 
    function add_article($category,$title,$comment)
	{
		$created = date("Y/m/d");
		$data = array(
						'Category_id'=>$category,
						'Title'=>'$title',
						'Description'=>$comment,
						'Created'=>$created,					 
					 );
					 $this->db->insert('article',$data);
					 //$item_id = $this->db->insert_id();
					/* echo "<pre>";
					print_r($data);
					die(); */
					if($this->db->affected_rows()>0){
						echo '<div class="alert alert-dismissable alert-success"><h4>Article Added Successfull</h4></div>';
						exit;
					}
					else{
						echo '<div class="alert alert-dismissable alert-danger"><h4>Somethng went wrong! please try later</h4></div>';
						exit;
					}
	}
	
	function delete_article($id)
	{
		if($this->session->userdata('role')=='admin')
		{
			$this->db->delete('article',array('id'=>$id));
		}
		else{
			echo '<div class="alert alert-dismissable alert-danger"><h4>Invalid User</h4></div>';
		}
	}
	
	function category_edit($type, $comment, $id){
        $data = array(
               'Type' => $type,
               'Description' => $comment
            );

        $this->db->where('id', $id);
        $this->db->update('category', $data); 
 
        if($this->db->affected_rows()>0){
            echo'<div class="alert alert-success alert-dismissible" role="alert" style="margin-top: -18px; padding: 10px;">
            <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <strong>Success!</strong> This item updated successfully.
            </div>';
        }
        else{
            echo'<div class="alert alert-warning alert-dismissible" role="alert" style="margin-top: -18px; padding: 10px;">
            <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <strong>Warning:</strong> No Change for update.
            </div>';
        }
   } 
 
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
	 
/* 	  function add_item($item, $comment){
        $created = date("Y/m/d");
        $this->db->set('item', $item);
        $this->db->set('comment', $comment);
        $this->db->set('created', $created);
        $this->db->insert('item');
        $item_id = $this->db->insert_id();
        
        if($this->db->affected_rows()>0){
            echo'<div class="alert alert-dismissable alert-success"><h4>Item Added Successfully</h4></div>';
//            $this->addHistory($item_id, $created);
            exit;
        }
        else{
            echo'<div class="alert alert-dismissable alert-danger"><h4>Somethng went wrong! please try later</h4></div>';
            exit;
        }
    } */
	
	 /*   function add_item($item, $comment)
		{
			$created = date("Y/m/d");
		$data = array('item'=>$item,
					  'comment'=>$comment,
					  'created'=>$created,				
					//$created = date("Y/m/d");				
					);
					$this->db->insert('item',$data);
					$item_id = $this->db->insert_id();
					echo "<pre>";
					print_r($data);
					if($this->db->affected_rows()>0){
						echo '<div class="alert alert-dismissable alert-success"><h4>Item Added Successfull</h4></div>';
						exit;
					}
					else{
						echo '<div class="alert alert-dismissable alert-danger"><h4>Somethng went wrong! please try later</h4></div>';
						exit;
					}
			}

				
		function delete_item($id)
		{
			if($this->session->userdata('role')=='admin')
			{
				$this->db->delete('item',array('id'=>$id));
			}
			else{
				echo "Invalid User";
			}
		}
		
		function edit_list($id)
		{
			$data['query'] = $this->db->query("select  *  from item where id = '$id'");
		}
		
		
		function list_edit($item, $comment, $id){
        $data = array(
               'item' => $item,
               'comment' => $comment
            );

        $this->db->where('id', $id);
        $this->db->update('item', $data); 
 
        if($this->db->affected_rows()>0){
            echo'<div class="alert alert-success alert-dismissible" role="alert" style="margin-top: -18px; padding: 10px;">
            <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <strong>Success!</strong> This item updated successfully.
            </div>';
        }
        else{
            echo'<div class="alert alert-warning alert-dismissible" role="alert" style="margin-top: -18px; padding: 10px;">
            <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <strong>Warning:</strong> No Change for update.
            </div>';
        }
   } 
	
	
}	*/


   


