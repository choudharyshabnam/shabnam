<?php

class Contact_model extends CI_Model
{
    
   function __construct() {
        parent::__construct();
    }
    
 
    function contacts($name,$email,$subject,$message, $created)
	{
		$created = date("Y/m/d");
		$data = array(
						'name'=>$name,
						'Email'=>$email,
						'subject'=>$subject,
						'message' =>$message,
						'Created'=>$created,					 
					 );
					 $this->db->insert('contactus',$data);
					 //$item_id = $this->db->insert_id();
					/* echo "<pre>";
					print_r($data);
					die(); */
					if($this->db->affected_rows()>0){
						echo '<div class="alert alert-dismissable alert-success"><h4>Contact Added Successfull</h4></div>';
						redirect('home/contact');
						exit;
					}
					else{
						echo '<div class="alert alert-dismissable alert-danger"><h4>Somethng went wrong! please try later</h4></div>';
						exit;
					}
	}
	

	

 
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
	 
