<?php

class Dashbord_model extends CI_Model
{
    
   function __construct() {
        parent::__construct();
    }
    

	
	
 	function add_transaction($item,$weight,$nug,$transaction_type,$date,$comment)
	{
		$total_weight = ($weight * $nug);
		$transaction = array('item_id' =>$item,
							 'weight'=>$weight,
							 'nug'=>$nug,
							 'total_weight'=>$total_weight,
							 'transaction_type'=>$transaction_type,
							 'created'=>$date,
							 'comment'=>$comment,
							);
		$this->db->insert('transaction',$transaction);
		echo "<pre>";
		print_r($transaction);
		if($this->db->affected_rows()>0)
		{
			echo '<div class="alert alert-dismissable alert-success"><h4>Transaction Successfull</h4></div>';
			exit;
		}
			else{
				echo '<div class="alert alert-dismissable alert-danger"><h4>Transaction Unsuccessfull</h4></div>';
				exit;
			}		
		
	}

		function delete_post($id)
		{
			if($this->session->userdata('role')=='admin')
			{
				$this->db->delete('transaction',array('id'=>$id));
			}
			else{
				echo 'invalid user';
			}
				
		}
    
	
	function view_edit($item,$weight,$nug,$transaction_type,$date,$comment,$id)
	{
		$total_weight = ($weight * $nug);
		$data = array(
		'item_id' => $item,
		'weight' => $weight,
		'nug' => $nug,
		'total_weight'=>$total_weight,
		'transaction_type' => $transaction_type,
		'created' => $date,
		'comment' => $comment,
		);
		$this->db->where('id',$id);
		$this->db->update('transaction',$data);
		if($this->db->affected_rows() > 0)
		{
			echo '<div class="alert alert-dismissable alert-success"><h4>This Post Updated Successfully </h4> </div>';
		}
		else{
			echo '<div class="alert alert-dismissable alert-danger"><h4>No Change Found </h4> </div>';
		}
	}
	
	function createUser()
	{
		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$password = sha1($this->input->post('cpassword'));
		$role = $this->input->post('role');
		$is_active = $this->input->post('is_active');
		$created = date("Y-m-d");
		
		$data = array(
		'user_name' => $name,
		'user_email' => $email,
		'password' => $password,
		'role' => $role,
		'is_active' =>$is_active,
		'd_o_c' => $created,
		);
		echo json_encode($data);
		$this->db->insert('auth', $data);
		
		if($this->db->affected_rows()> 0)
		{
			return TRUE;
		}
		else{
			return FALSE;
		}
	}
	
	function searchItem($item)
	{
		$item = trim($item);
		$sql = "SELECT item.item, item.id as itemID, transaction.id, transaction.weight, transaction.nug, transaction.transaction_type, transaction.comment, transaction.created from item RIGHT JOIN transaction ON transaction.item_id = item.id WHERE transaction.item_id = $item";        
        $query = $this->db->query($sql);
		/* echo "<pre>";
		print_r($query);
		die(); */
		/* $sql = "Select item.item, item.id as ItemId, transaction.id, transaction.weight,transaction.nug,transaction.total_weight,transaction.transaction_type,transaction.comment from item RIGHT JOIN ON transaction.item_id = item.id WHERE transaction.item_id=$item";
		$query = $this->db->query($sql); */
		
		 $sno = 1;
       foreach ($query->result() as $row)
       {    
           $created = strtotime($row->created);
           echo'<tr><td>'.$sno.'</td><td>'.$row->item.'</td><td>'.$row->weight.'</td><td>'.$row->nug.'</td><td>'.($row->weight * $row->nug).'</td><td>'.$row->transaction_type.'</td><td>'.date('F jS Y', $created ).'</td><td>'.$row->comment.'</td><td>
                <div class="btn-group"><a href="'.base_url().'dashbord/edit_entry/'.$row->id.'/'.$row->item.'" class="btn btn-info btn-sm" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
                <a href="#" db_id="'.$row->id.'" class="btn btn-danger btn-sm btn_delete" title="Delete"><i class="glyphicon glyphicon-remove"></i></a></div>
                </td></tr>';
           
           $sno = $sno+1; 
       }  
	}
	
	
	function searchAdvance($from, $to)
	{
		$from = trim($from);
		$to = trim($to);
		$condition = "between '$from' AND '$to'";
		if(empty($from))
		{
			echo '<tr><td colspan="9"><h2 style="color: #9F6000;">Sorry ! no Search Result found</h2></td></tr>';
			exit;
		}
		if(!empty($from) AND empty($to))
		{
			$condition = "='$from'";
		}
		/* echo "<pre>";
		 print_r($condition);
die();	 */	 
		$sql = "SELECT item.item, item.id as ItemID, transaction.id, transaction.weight, transaction.nug, transaction.transaction_type, transaction.comment, transaction.created from item RIGHT JOIN transaction ON transaction.item_id = item.id WHERE transaction.created $condition";
		//$sql = "select * from transaction where created $condition";
		//echo "<pre>";
		 //print_r($sql);
		 //die();
		$query = $this->db->query($sql);
		$sno = 1;
		foreach($query->result() as $row)
		{
			 $created = strtotime($row->created);
			echo '<tr><td>'.$sno.'</td><td>'.$row->item.'</td><td>'.$row->weight.'</td><td>'.$row->nug.'</td><td>'.($row->weight * $row->nug).'</td><td>'.$row->transaction_type.'</td><td>'.date('F jS Y', $created ).'</td><td>'.$row->comment.'</td>
			<td><div class="btn-group"><a href="'.base_url().'dashbord/edit_entry/'.$row->id.'/'.$row->item.'" class="btn btn-info btn-sm" title="Edit"><i class="glyphicon glyphicon-pencil"></i></a>
                <a href="#" db_id="'.$row->id.'" class="btn btn-danger btn-sm btn_delete" title="Delete"><i class="glyphicon glyphicon-remove"></i></a></div>
				</td></tr>';
			$sno = $sno+1;
		}
	}
	
	
/* 	function delete_user($id)
	{
		if($this->session->userdata('role')== 'admin')
		{
			$this->db->delete('auth',array('id'=>$id));
			if($this->db->affected_rows() > 0)
			{
				$this->session->set_flashdata('falsh','<p class="alert alert-success"> One Item Deleted Seccessfully</p>');
			}
			else{
				$this->session->set_flashdata('falsh','<p class="alert alert-danger">You have no rights to delete</p>');
			}
			
		}else{
			redirect('dashbord/manageUser');
		}
		
	} */

	
	  /*  function delUser(){
        if($this->session->userdata('role') == 'admin'){
       $id = $this->input->get_post('id');
       $this->db->where('id', $id);
       $this->db->delete('auth');
       if($this->db->affected_rows()>0){
       $this->session->set_flashdata('falsh', '<p class="alert alert-success">One item deleted successfully</p>');    
       }
       else{
           $this->session->set_flashdata('falsh', '<p class="alert alert-danger">Sorry! deleted unsuccessfully</p>');    
       }
       
        }
        else{
            $this->session->set_flashdata('falsh', '<p class="alert alert-danger">Sorry! You have no rights to deltete</p>');    
            
        }
        redirect('dashbord/manageUser');
       exit;
   } */
	
	
	
	
	
	
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

   
   
